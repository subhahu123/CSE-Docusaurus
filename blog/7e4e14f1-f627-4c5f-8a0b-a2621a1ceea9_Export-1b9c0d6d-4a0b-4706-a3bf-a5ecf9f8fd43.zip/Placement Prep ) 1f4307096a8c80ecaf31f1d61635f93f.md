# Placement Prep :)

<aside>
📢

Tech Trends:f

[tips :](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/tips%201f5307096a8c80c0a215f1e3ec20f118.md)

</aside>

[ design patterns   and oops](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/design%20patterns%20and%20oops%201f4307096a8c80e4af49c007a406d8ca.md)

[computer networks](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/computer%20networks%201f4307096a8c808eb98af12c95b2268d.md)

[System Design ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/System%20Design%201f4307096a8c801eb24ed27973fefb90.md)

[interview & negotiation ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/interview%20&%20negotiation%201f4307096a8c80fa84afe52bf2c8ca59.md)

[DSA and CP](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/DSA%20and%20CP%201f4307096a8c80f2834de36f5acc7d66.md)

[OA ROUNDS OF COAMPANIES ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/OA%20ROUNDS%20OF%20COAMPANIES%201f4307096a8c8060b87fcd5c4be8d8c2.md)

[TOC and automata ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/TOC%20and%20automata%201fc307096a8c801db28ce3af5ff32ece.md)

[operating system](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/operating%20system%201f4307096a8c80ddb74ed32a5ff01545.md)

[dbms ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/dbms%201f4307096a8c80508022f6cfac0ae4e2.md)

[Behavioural ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/Behavioural%201f4307096a8c80608386d954d83fdc38.md)

[Application: ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/Application%201f4307096a8c803aa41ded8b37481753.md)

[gate cse ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/gate%20cse%201f5307096a8c803e9b0bfc89b47bec1e.md)

[collage nice people :](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/collage%20nice%20people%201f6307096a8c80f4a48df7a63ad64ede.md)

[certifactes that matters ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/certifactes%20that%20matters%201f8307096a8c809cac66f45dbd9fe00d.md)

<aside>
💯

important links :

https://fountn.design/design-resources/

</aside>

| system design  | oops  | cn  | dbms  | operating system  |
| --- | --- | --- | --- | --- |
| [hellointerview](https://www.hellointerview.com/learn/system-design/in-a-hurry)  |  |  |  |  |
| [design gurus](https://www.designgurus.io/) |  |  |  |  |
| educative io |  |  |  |  |
| https://github.com/karanpratapsingh/system-design?tab=readme-ov-file#what-is-system-design |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

<aside>
💯

imp dsa websites :

https://algomaster.io/practice/dsa-patterns

</aside>

<aside>
💯

tips by a reditor 

[Intervew Prep](https://www.reddit.com/r/leetcode/?f=flair_name%3A%22Intervew%20Prep%22)

YOE: 7.5 Skills: Distributed Systems

Offers:

- Apple ICT4 (Dist Systems)
- Apple ICT4 k8s
- Block L6
- PayPal T26
- Gusto L4
- Meta L5

No Offer:

- Roblox

Quick notes on what worked for me:

Getting Interviews:

- Include a one sentence summary of your scope of role before your accomplishments.
- Quantity of applications matters more than quality. I completed ~250.
- Buy LinkedIn premium and proactively contact recruiters. If they are in your area buy them a coffee. My interviews for Block, and Gusto were a direct result of this.

Prep

- DSA
- System Design
- Behavioral

DSA:

- Grokking coding interview patterns.
- Recently asked LeetCode prep. Try to answer questions asked by targets in 90 days. Not always possible. Do your best.
- USE YOUR RE-ROLL. If you’re in a coding screen and you get a problem you know you can’t solve tell the interviewer that you solved it recently. You’ll probably get another.

System Design

- Designing Data Intensive Systems
- The Google SRE Book for Senior+
- Microservice patterns
- System Design insiders guide Vol 2. Vol 1 is not relevant for Senior+.
- Hello Interview for practice
- If you are below Senior and not cloud architect certified this is probably the best practice you can get.
- Skim ALL of the docs for one relational database, one KV database, Elastic search, Redis (it’s so versatile), one message queue like Rabbit, NATS, or Kafka

Behavioral:

- Write a one page narrative for every major project that may come up in STAR format. Recall as much detail as possible. Include a brief description of your team and how it fits into business at the top. Don’t memorize. Just priming your working memory.

General:

- Take care of yourself. Eat well. Go do fun stuff with friends and family. Try not to take rejection personally.
</aside>

# manage these links later :
Few useful links

- https://github.com/rgbedin/interview-prep/blob/d0aeaeff33c006a4d34a13b040284ba11128c052/algo-sheet.md
- https://www.techinterviewhandbook.org/software-engineering-interview-guide/
- https://interviewguide.dev/
- https://github.com/karanpratapsingh/system-design?tab=readme-ov-file#what-is-system-design
- https://interviewguide.dev/
- https://github.com/jwasham/coding-interview-university?tab=readme-ov-file#interview-prep-books

# COURSE SITE :

- ALGOMONSTER
- TLE EMILIMINATOR
- ECUCATIVE .IO
- DESIGN GURUS
- TUF : STRIVER
- https://algomaster.io/learn/lld
- https://www.enjoyalgorithms.com/crack-system-design-interview/
- 
- 

 

[Imp resources for learning ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/Imp%20resources%20for%20learning%201fc307096a8c80dab1a8f9061a0b90be.md)

[UG_curriculum  ](Placement%20Prep%20)%201f4307096a8c80ecaf31f1d61635f93f/UG_curriculum%201fc307096a8c8064a81bc2022202483e.md)