# collage nice people :

from senior batchs

- jigyasu sir  (zscaler  data engineer )
- yashesh bhavsar
- dhruv bhalodia
- yuvraj sir
- trijay sir
- krityuk
- lakshaya dhiman
- jaideep jaiswal
- sout wale amazon vaketesh
- 
- 

my batch :

- bala
- nahngom
- rudra
- jatin
- deep
- rishabh
- akshat
- abhijeet
- apurav
- arjun
- vedang
- ankesh
- ankit
- amit
- yansu
- tejesh
- ram bhadra
- ram charan
- param
- sriram venkat
- 
- pura list chaiye

junior batchs :

-