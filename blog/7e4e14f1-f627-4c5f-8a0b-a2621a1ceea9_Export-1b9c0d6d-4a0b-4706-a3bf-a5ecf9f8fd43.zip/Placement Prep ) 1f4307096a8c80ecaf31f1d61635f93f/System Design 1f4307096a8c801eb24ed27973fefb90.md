# System Design

<aside>
💯

# System Design :

**Videos**

A collection of videos based on distributed systems.

**Introduction / Interviews**

- [*Gaurav Sen - System Design Series](https://www.youtube.com/watch?v=xpDnVSmNFX0&list=PLMCXHnjXnTnvo6alSjVkgxV-VH6EPyvoX) -* Good resource for people who want to learn more about system design, introduces the topic in a very easy to understand way.
- [*Tech Dummies - System Design Series](https://www.youtube.com/watch?v=mhUQe4BKZXs&list=PLkQkbY7JNJuBoTemzQfjym0sqbOHt5fnV)* - Another introduction to system design.
- [*Mock System Design Interview at Google*](https://www.youtube.com/watch?v=q0KGYwNbf-0) - Overview of what an interview on system design would look like from the perspective of a flawed but close fulfilling of the requirements. Key thing here is how the interaction with the interviewer goes.
- [*Google Preparation Guide](https://www.youtube.com/watch?v=Gg318hR5JY0)* - A quick video explaining how they interview.
- [System Design Interview](https://www.youtube.com/c/SystemDesignInterview/) - YouTube channel focussed on content specific to system design interviews, with detailed explanation of a variety of problems.
- [Intro to Architecture and System Design Interviews](https://www.youtube.com/watch?v=ZgdS0EUmn70) - A youtube video with Jackson Gabbard with good info about system design interviews.
- [System Design Introduction for Interview](https://www.youtube.com/watch?v=UzLMhqg3_Wc) - Tushar's intro to System Design.
- [*Distributed Systems](https://www.youtube.com/playlist?list=PLOE1GTZ5ouRPbpTnrZ3Wqjamfwn_Q5Y9A) -* This is an introductory course in Distributed Systems made by Chris Colohan. He got PhD from Carnegie Mellon, then spent 10 years working at Google building distributed systems.
- [*The Easy Way](https://www.youtube.com/channel/UCVZfU1sp66H9d4sdYx4iNkQ)* - Up and coming channel with easy to understand videos about Distributed Systems.
- [System Design by SDE Skills](https://www.youtube.com/playlist?list=PLBtMh4xfa9FHSMKKgPZcPfoPbZmND5PC-) - Good resource for people who are preparing for System Design interviews, there are multiple system design mock interviews and deep dives.
- [*System Design by CodeKarle](https://www.youtube.com/watch?v=EpASu_1dUdE&list=PLhgw50vUymyckXl3D1IlXoVl94wknJfUC)* - Another great free resource, a list of commonly asked interview questions.

**Advanced**

- [The evolution of Reddit Architecture](https://www.youtube.com/watch?v=nUcO7n4hek4) - Overview of how Reddit system design scaled.
- [6.824 Distributed Systems by MIT](https://www.youtube.com/playlist?list=PLrw6a1wE39_tb2fErI4-WkMbsvGQk9_UB) - Graduate level course on distributed systems from MIT (2020).
- [CSE138 Distributed Systems by UCSC](https://www.youtube.com/playlist?list=PLNPUF5QyWU8O0Wd8QDh9KaM1ggsxspJ31) - Undergraduate course on distributed systems from UCSC (2020).

yt or else where :
- gaurav sen , arpit bhayani , byte byte go , hello interview ,
- https://www.youtube.com/@jordanhasnolife5163/playlists → notes: [https://jordanhasnolife.substack.com/](https://jordanhasnolife.substack.com/)
https://drive.google.com/drive/folders/1ChodcbMZ4KqS9WP9gin4sLVdCsgD3uoE?usp=drive_link
- 
</aside>

<aside>
💯

Arpit Bhayani system design course :

## **Course curriculum**

### **Introduction to System Design**

- What is system design?9 mins
- How to approach System Design?17 mins
- How to understand that you have built a good system?9 mins

**Databases**

### **All Things Databases**

- Relational databases20 mins
- Database Isolation Levels19 mins
- Scaling Databases18 mins
- Sharding and Partitioning16 mins
- Non-relational Databases15 mins
- Picking the right database13 mins

**Caching**

### **All Things Caching**

- Understanding Caching12 mins
- Populating and Scaling Caches11 mins
- Caching at different levels of architecture19 mins

**Asynchronous Systems**

### **Asynchronous Processing**

- Message Queues16 mins
- Message Streams and Kafka Essentials23 mins
- Real-time PubSub6 mins

**Resiliency**

### **Designing for Resiliency**

- Load Balancers16 mins
- Circuit Breakers13 mins
- Data Redundancy and Recovery9 mins
- Leader Election for auto-recovery8 mins

**Essentials**

### **Essentials at Scale**

- Bloom Filters21 mins
- Consistent Hashing27 mins
- Client-server and Communication Protocols22 mins
- Blob Storage and S316 mins
- Introduction to Big Data17 mins

**Consumer Facing**

### **Designing Consumer Systems**

- Designing e-Commerce Product Listing20 mins
- Designing Tinder Feed32 mins
- Designing and Scaling Notifications38 mins
- Designing Twitter Trends30 mins

**Common Utilities**

### **Designing Utilities**

- Designing URL Shortners48 mins
- Designing API Rate Limiter26 mins
- Designing Realtime Abuse Masker22 mins
- Designing Web Crawler54 mins

**Critical Systems**

### **Designing systems that matter**

- Designing GitHub Gists28 mins
- Designing Fraud Detection25 mins
- Designing Recommendation Engine37 mins
</aside>

<aside>
📢

# 📘 LLD Crash Course for Freshers, SDE-I, SDE-II, SSE-I, SSE-II | Complete Guide (ARYAN M.)

**🔗 YouTube Video:** [Watch here](https://www.youtube.com/watch?v=33o_j_00N-8&t=182s)

**🎥 Duration:** ~7.5 hours

**🎯 Ideal For:** 0–8 years of experience (Primarily 0–6 years)

---

## 🎯 Audience & Scope

- **Freshers to SSE-II** (0 to ~8 years of experience)
- Especially useful if:
    - Your interview is **tomorrow**, in **1 week**, or **1 month**
    - You're **transitioning from DSA to LLD-focused rounds**
- Based on general industry levels (averaged across companies):
    - `SDE-I`: <2 years
    - `SDE-II`: <4 years
    - `SSE-I`: <6 years
    - `SSE-II`: <8 years

---

## 🛠️ LLD Preparation Strategy

### 1. **Freshers / Early SDE-I**

- 📌 **Approach**:
    - Focus on **how to approach LLD problems**
    - Practice tips, tricks, and structure
- 🧠 **Core Concepts**:
    - **OOP Fundamentals** (Classes, Inheritance, Abstraction, Encapsulation, Polymorphism)
    - **SOLID Principles**
        - S: Single Responsibility
        - O: Open/Closed
        - L: Liskov Substitution
        - I: Interface Segregation
        - D: Dependency Inversion

---

### 2. **Design Patterns (Essential for SDE-II and above)**

### 🏗️ Creational Patterns

- ✅ Focus:
    - **Factory**
    - **Builder**
    - **Singleton**
- ❌ Ignore (if time-constrained):
    - Abstract Factory, Prototype, etc.

### 🔁 Behavioral Patterns

- ✅ Must-Know:
    - **Strategy**
    - **Observer**
    - **Iterator**
    - **Command**
    - **State**

### 🧱 Structural Patterns

- ✅ Key Ones:
    - **Adapter**
    - **Composite**

---

## 🎮 Must-Practice LLD Problems

| ✅ **Must Do** | ❌ **Optional / Avoid (Time-Consuming)** |
| --- | --- |
| Tic Tac Toe | Chess Game (too long) |
| Snake Game | Splitwise (DSA-heavy, backtracking) |
| Parking Lot | ATM Machine (State pattern, uncommon) |
| File System | Vending Machine |
| Car Rental | Elevator System (time-intensive) |
|  | Inventory System |

> 📝 These problems are often sufficient to demonstrate core design skills.
> 

---

## 🚨 Market Trend Shift

- DSA-only rounds are **declining** due to:
    - 📉 **Cheating (AI, shared repos)**
    - 💰 **Increased cost of in-person interviews**
- Companies like **Coinbase** are now focusing on:
    - **LLD**
    - **System Design**
    - **Speed of ideation**
    - **Solution feasibility**

---

## 🔄 For Experienced Engineers (3+ Years)

### 🔧 Multi-threading (High Priority)

- Must know:
    - Threads, Locks, Semaphores
    - Thread-safe design, race conditions
- Common questions:
    - **Producer-Consumer**
    - **Read-Write Locks**
    - **Thread Pool Implementation**
    - **Dining Philosophers Problem**

> 🔥 Highly valued in top companies paying ₹60+ LPA (e.g., Rubrik)
> 

---

## 🔥 LLD + Multi-threading Combo Problems (Advanced)

- 🟢 **Very Important**:
    - **Thread-safe Cache (more than simple LRU)**
    - **Rate Limiter**
- ⚠️ Others (optional but complex):
    - Payment Gateways
    - Distributed Job Scheduling

---

## 📌 Final Tips

- Focus more on **understanding design principles** than memorizing
- Implement at least 4–5 **real-world problems**
- Use GitHub to showcase your LLD projects
- If short on time, **prioritize starred patterns and problems**
- Don’t skip **multi-threading** if you're at or beyond 3 years of experience

---

## 📚 Suggested Study Order

1. ✅ OOP + SOLID
2. ✅ Creational Design Patterns
3. ✅ Behavioral + Structural Patterns
4. ✅ Core LLD Problems (Tic Tac Toe, Snake Game...)
5. ✅ Multi-threading Concepts
6. ✅ LLD + Multi-threading Problems (Cache, Rate Limiter)

---

Let me know if you'd like:

- A Notion template
- Flashcards for design patterns
- A GitHub repo starter for LLD problems
- Printable LLD interview checklist ✅

4o

**You said:**

</aside>

<aside>
📌

frontend system design (Product Sense ,UI Architecture , Machine Coding/ Component Design rounds ): 

1. chirag goyal (microsoft ) hindi me 
2. frontend system design playlist eng 
3. 
</aside>