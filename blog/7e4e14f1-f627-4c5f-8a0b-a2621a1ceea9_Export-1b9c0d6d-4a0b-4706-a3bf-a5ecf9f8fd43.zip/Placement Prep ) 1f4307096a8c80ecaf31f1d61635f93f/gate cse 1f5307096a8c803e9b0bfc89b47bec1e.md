# gate cse

https://docs.google.com/spreadsheets/d/1I8U_pNRr_ElGCrNUanArE04gsMKaHgTJdzlJKu0l2QQ/edit?usp=sharing mega docs gate 

<aside>
📢

**Gate Wallah CS Faculty**

1)Khaleel Ur Rahaman Khan Sir(28 years Experience)
2)Satish Yadav Sir (12+ Exp)
3)Chandan Jha Sir( Air 23 and 26 ,11+ EXP)
4)Ankit Doyla Sir
(Exp 10+ GATE AIR 159|)
5)Vishal Soni Sir
Ex-IES Officer (AIR 25)
6)Amulya Ratan Sir
(More than 10 years experience in training aspirants)

</aside>

<aside>
📢

yt videos : ankit khurana , 

cn : 

- https://www.youtube.com/watch?v=H4ystojVBak&list=PLC36xJgs4dxHT-TxTy3U1slr5RaBJGaLd
- pyq series : https://www.youtube.com/watch?v=ZF9CKK7Z_Yc&list=PLC36xJgs4dxFrs7jrqgi3R30hyHqtZKMV
- 

dbms: 

- https://www.youtube.com/watch?v=k7Y5SibZhqw&list=PLC36xJgs4dxGcz7nZaxGxxmbJrcgDXhFk

descrete maths : 

- https://www.youtube.com/watch?v=bfAYYLamQPQ&list=PLC36xJgs4dxEYmhzVBW7nBdftFZ4xmiF1

os :

- https://www.youtube.com/playlist?list=PLC36xJgs4dxEGlPPsvshTRh35Vv-Eg_4b
- dfs

toc:

- https://www.youtube.com/watch?v=1PD2EA3jPIs&list=PLC36xJgs4dxGvebewU4z2CZYo-8nB93E7
- 

</aside>

<aside>
📢

ankit doyla

cn :

- https://www.youtube.com/watch?v=3SbtNuK5YZ8&list=PLOG_8OlGMp73hMyn-WX1M2Q4ON98DmaRq
- https://www.youtube.com/watch?v=pGWxdTJPjKE&list=PL3eEXnCBViH-hlNCNwdfV7VrEcTquANGa
- pyq last 30 years : https://www.youtube.com/watch?v=tQkV30512FI&list=PLOG_8OlGMp71eh-AeXeH3Rq17YeHzia1-
- 

</aside>

<aside>
📢

viwadeep sir (vgsir ) 

- https://youtube.com/playlist?list=PLG9aCp4uE-s0xddCBjwMDnEVyc523WbA2&si=UEHnaq8Jj2UW27TZ
</aside>

<aside>
📢

go classes

toc: 

- https://www.youtube.com/watch?v=a2m_f9Ihcx0&list=PLIPZ2_p3RNHhXeEdbXsi34ePvUjL8I-Q9
</aside>

<aside>
📢

reddy sir god :

</aside>

<aside>
📢

khaleel sir god :

</aside>

<aside>
📢

christys classes (long)

</aside>

<aside>
📢

amulya ratan (short ) 

</aside>

<aside>
📢

toc - gtehub or lallesham sir 

</aside>

<aside>
📌

rbr sir 

- https://www.youtube.com/watch?v=Qkwj65l_96I&list=PLEbnTDJUr_IcPtUXFy2b1sGRPsLFMghhS
- https://www.youtube.com/watch?v=UXMIxCYZu8o&list=PLEbnTDJUr_IegfoqO4iPnPYQui46QqT0j
- https://www.youtube.com/watch?v=aGjL7YXI31Q&list=PLEbnTDJUr_IeHYw_sfBOJ6gk5pie0yP-0
- https://www.youtube.com/watch?v=j4fDYX5VZF0&list=PLEbnTDJUr_Ica5kK6UypsWpf95Ut2sK3o
- https://www.youtube.com/watch?v=2i2N_Qo_FyM&list=PLEbnTDJUr_If_BnzJkkN_J0Tl3iXTL8vq
- https://www.youtube.com/watch?v=bCbkIJwjvtI&list=PLEbnTDJUr_If_GCGDEOYensUC5Ur-L9MR
- https://www.youtube.com/watch?v=jyu5RKDwkTA&list=PLEbnTDJUr_IdI9QZ7bkrhMX2ZpNW0dZUo
- https://www.youtube.com/watch?v=eV3NidpjfNg&list=PLEbnTDJUr_IdiveZ4bvOc1Oh2zEp7J8z6&pp=0gcJCV8EOCosWNin
- https://www.youtube.com/watch?v=W59hzBJ8QTk&list=PLEbnTDJUr_IeCNOXeg69jq7uUDmYzs6Ez
- one shot https://www.youtube.com/playlist?list=PLEbnTDJUr_Ied4fCZ1iVYrM5PVfwUBalb 8 videos
- 
- 
</aside>

note : 

VG sir’s COA is actually good  but not good os , for os do  Srikant verma chikori sir, gates applied

For discrete math, probability and pretty much all the math subjects refer someone else and for COA Vishwadeep Gothi's COA playlist. Except that everything from rbs . His course may feel outdated now but after solving pyqs and few tests you'll know what's missing, read that from someone else.

rbs sir is god litterally old lectures 

pirate  course of gte made easy and unacademy

 
https://docs.google.com/spreadsheets/u/0/d/140zQejFshwH1yGjONWs5e5A0ySiMJiwmWa28niLnuxA/htmlview#

<aside>
📌

sanchit jain 

https://www.youtube.com/playlist?list=PLmXKhU9FNesTaKDC-MKWt-rFuB8OwqrCY - dbms ,dm,dld,coa,dsa,toc,os,cn,algo

</aside>

<aside>
📌

neso 

</aside>

<aside>
💡

GO classes 

Subjects Duration
Table Of Content

---
Theory of Computation:
Module 1: 22 Hours
Module 2: 25.37 Hours
Module 3: 5.38 Hours
Module 4: 11.28 Hours
Module 5: 39.42 Hours
Module 6: 17.58 Hours
Total= 157.25 Hours
Computer Architecture:
Basic Comp. of Computer & Main Mem.: 14 Hours
The CPU: 27.95 Hours Cache Memory: 11.43 Hours Pipeline: 11.45 Hours
Floating Point Representation:
4.35 Hours
Total= 69.18 Hours
Operating System:
Intro to Os: 71.15 Hours
File systems: 35 Hours
OS PYQs series: 15.76 Hours
(Youtube)
Total= 75.5 Hours (Excluding Pyqs).
Data Structures:
Linked List: 16 Hours
Logarithm Basics: 2.18 Hours
Asymptotic Notation/Analysis: 9.58 Hours
Stack & Queue: 7.71 Hours
Binary Trees: 8 Hours
AVL Tree:5.1 8Hours
Heap: 8.85 Hours
Hashing: 4.63 Hours
Row & Column major in Arrays: 0.77 Hours
More Live Sessions: 6.15 Hours
Total: 60.21 Hours
Algorithms:
Why Study & Asymptotic(f rom DS): 9.95 Hours
Time comp. of Recursive Prag: 3.67 Hours
Divide & Conquer (P-1): 4.95 Hours
Max & Min of Nos: 2.9 Hours
Divide & conquer (P-2): 6 Hours
Sorting Algorithms: 3.47 Hours
BFS & DFS: 7 Hours
Shortest Path Algorithms: 5.1 Hours
Minimum Spanning Tree: 4.87
Hours More Greedy Algorithms: 3.67 Hours
Dynamic Programming: 7.33 Hours
More Dynamic Programming Algo: 1.43 Hours
Total: 60.34
Engineering Maths
Linear Algebra: 30 hours
Probability: 28 hours
Calculus: 8-10 hours
Total= 66 hours
Compiler Design:
Module 1: 13.15 Hours
Module 2: 11.8 Hours
Module 3: 2.33 Hours
Module 4: 19.66 Hours
Total= 47 Hours
Digital Logic
Module 1: 26.72 Hours
Module 2: 11.97 Hours
Module 3: 14.93 Hours
Module 4: 6.65 Hours
Module 5: 35.87 Hours
Total= 96.14 Hours
Computer Networks:
Module 1: 9.87 Hours
Module 2: 28.73 Hours
Module 3: 12 Hours
Module 4: 10.93 Hours
Module 5: 14.5 Hours
Module 6: 1 Hour
Total= 77.03 Hours
Database Management Systems:
Module 1: 38 Hours
Module 2: 16.5 Hours
Module 3: 7.4 Hours
Module 4: 22 Hours
Module 5: 8 Hours
Module 6: 32 Hours
Module 7: 31.28 Hours
Module 8: 9 Hours
Total= 165 Hours
Discrete Maths:
Module 1: 22.37 Hours
Module 2: 34 mins
Module 3: 32.78 Hours
Module 4: 29.67 Hours
Module 5: 43.6 Hours
Module 6: 13.45 Hours
Module 7: 19.73 Hours
Module 8: 39.92 Hours
Module 9: 46.17 Hours
Total=  247.69 Hours
C-Programming:
Module 1: 10.05 Hours
Module 2: 5.63 Hours
Module 3: 20.76 Hours
Total= 36.44 Hours
Final Total: 1,158 Hours

</aside>

![image.png](gate%20cse%201f5307096a8c803e9b0bfc89b47bec1e/image.png)

Section 1 : Aptitude, Eng maths, Discrete maths. 
Section 2 : TOC, Compiler design. 
Section 3 : OS, COA, DBMS 
Section 4 : C language, DS, Algorithm 
Section 5 : digital logic, computer network

Choose any section and do it in the sequence written