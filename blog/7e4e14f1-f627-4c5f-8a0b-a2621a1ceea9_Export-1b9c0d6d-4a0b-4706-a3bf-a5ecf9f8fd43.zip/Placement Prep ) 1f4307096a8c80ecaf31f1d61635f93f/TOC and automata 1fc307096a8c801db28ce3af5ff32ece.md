# TOC and automata

topics 

<aside>
📌

yt links 

- https://www.youtube.com/playlist?list=PLmXKhU9FNesSdCsn6YQqu9DmXRMsYdZ2T - sanchit jain  one shot 12 hors and 8 hours  or follow  playlist
- f
- 
</aside>

<aside>
📌

syllabus :

- Basics of TOC
- Operations on Strings
- DFA
- DFA Minimization
- NFA
- NFA to DFA Conversion
- ε-NFA
- ε-NFA to NFA Conversion
- Regular Language Identification
- Regular Expressions (RE)
- FA to RE
- RE to FA
- Chomsky Classification of Grammars
- Regular Grammar to Regular Expressions
- Decision & Closure Properties of Regular Languages
- Moore and Mealy Machine
- Push Down Automata (PDA)
- Context Free Language Identification
- Context Free Grammar
- Decision & Closure Properties of Context-Free Languages
- Turing Machine Designing
- Versions of Turing Machines
- Halting Problem of Turing Machines
- Universal Turing Machines
- Linear Bounded Automata
- Decision & Closure Properties of Recursive & Recursively Enumerable Languages
</aside>