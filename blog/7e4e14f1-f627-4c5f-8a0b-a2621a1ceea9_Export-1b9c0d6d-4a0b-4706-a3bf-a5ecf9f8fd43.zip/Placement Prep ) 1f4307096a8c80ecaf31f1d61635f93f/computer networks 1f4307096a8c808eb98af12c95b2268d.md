# computer networks

<aside>
📢

# best resources

amit khurana sir : 

https://www.youtube.com/watch?v=H4ystojVBak&list=PLC36xJgs4dxHT-TxTy3U1slr5RaBJGaLd

https://www.youtube.com/watch?v=RrdXkZ_AUeY&list=PLsK0l-DkyTHuLX80VJaU687B3AsGWAGSR

rbr sir :

neso  :

khaleel sir :

</aside>