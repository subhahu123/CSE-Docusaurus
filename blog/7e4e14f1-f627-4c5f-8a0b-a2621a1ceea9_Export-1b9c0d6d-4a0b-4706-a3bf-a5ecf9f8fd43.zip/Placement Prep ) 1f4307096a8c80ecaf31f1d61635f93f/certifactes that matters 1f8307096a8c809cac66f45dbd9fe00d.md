# certifactes that matters

[devops ](certifactes%20that%20matters%201f8307096a8c809cac66f45dbd9fe00d/devops%201f8307096a8c80479382edc46f0c24de.md)