# Top Paying Companies In India — SDE roles

# SDE level 1 salaries in india :

[Typically 0-2 years of experience](Top%20Paying%20Companies%20In%20India%20%E2%80%94%20SDE%20roles%201f7307096a8c8077aa75d42bb21e005c/Typically%200-2%20years%20of%20experience%201f7307096a8c80258952d2eba0809f2d.csv)

---

# SDE level 2 salaries in india :

[Typically 2-5+ years of experience](Top%20Paying%20Companies%20In%20India%20%E2%80%94%20SDE%20roles%201f7307096a8c8077aa75d42bb21e005c/Typically%202-5+%20years%20of%20experience%201f7307096a8c80ecbff7ef5bdae9a2d4.csv)

---

# SDE level 3 :

[Typically 5+ years of experience.](Top%20Paying%20Companies%20In%20India%20%E2%80%94%20SDE%20roles%201f7307096a8c8077aa75d42bb21e005c/Typically%205+%20years%20of%20experience%201f7307096a8c80d2994dcd1cecf9181b.csv)

---

# Staf eng level 4 :

[Typically 10+ years of experience](Top%20Paying%20Companies%20In%20India%20%E2%80%94%20SDE%20roles%201f7307096a8c8077aa75d42bb21e005c/Typically%2010+%20years%20of%20experience%201f7307096a8c807bbdd4f949cb944201.csv)

---

# Principal engineer+ (level 5+)

[Untitled](Top%20Paying%20Companies%20In%20India%20%E2%80%94%20SDE%20roles%201f7307096a8c8077aa75d42bb21e005c/Untitled%201f7307096a8c805f97e1f4f7b37164b1.csv)

<aside>
📢

notes : if you want 8 figure salary 

[💼 **Top Companies Paying 1 Cr+ (INR)**](Top%20Paying%20Companies%20In%20India%20%E2%80%94%20SDE%20roles%201f7307096a8c8077aa75d42bb21e005c/%F0%9F%92%BC%20Top%20Companies%20Paying%201%20Cr+%20(INR)%201f7307096a8c80c693c2edd983e7b019.md)

- [indianTechsalries](https://docs.google.com/spreadsheets/d/1zc8q1lXHd-lFd0avY8iDqNpin7shlwgz-U6ZglnE1PE/edit?usp=sharing)- gcc/BigTech ,unicorn , ites(service based )
- https://6figr.com/in/salary
- https://www.levels.fyi/companies
- hgfg
- 
</aside>