# Untitled

Rank: 13
Company: https://www.levels.fyi/company/Nvidia/salaries/
Title Name: https://www.levels.fyi/company/Nvidia/salaries/
CompensationBase | Stock | Bonus: ₹12,215,7427.3M | 4.9M | N/A
Files: https://img.logo.dev/nvidia.com?size=256&token=pk_Ez-J4YOpSS-Bjtug_T41Dw