# Untitled

Rank: 10
Company: https://www.levels.fyi/company/Microsoft/salaries/
Title Name: https://www.levels.fyi/company/Microsoft/salaries/
CompensationBase | Stock | Bonus: ₹12,613,0867M | 5.6M | N/A
Files: https://static.levels.fyi/microsoftlogo.png