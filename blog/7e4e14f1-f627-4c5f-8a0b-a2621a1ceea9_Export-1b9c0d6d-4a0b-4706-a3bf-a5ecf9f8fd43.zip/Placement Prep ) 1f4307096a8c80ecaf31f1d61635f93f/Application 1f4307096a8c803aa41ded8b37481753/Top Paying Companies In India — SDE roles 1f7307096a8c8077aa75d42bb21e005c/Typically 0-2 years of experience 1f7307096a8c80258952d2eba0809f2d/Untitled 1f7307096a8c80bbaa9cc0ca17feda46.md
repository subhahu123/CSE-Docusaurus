# Untitled

Rank: 10
Company: https://www.levels.fyi/company/Zynga/salaries/
Title Name: https://www.levels.fyi/company/Zynga/salaries/
CompensationBase | Stock | Bonus: ₹4,097,6603M | 1.1M | N/A
Files: https://img.logo.dev/zynga.com?token=pk_Ez-J4YOpSS-Bjtug_T41Dw