# 💼 Top Companies Paying 1 Cr+ (INR)

These include:

- **HFTs (High Frequency Trading firms)** like:
    - **Graviton**
    - **Quadeye**
    - **NK Securities**
    - **Jane Street** (even if no India office, hires IITians for NY)
- **Big Tech & Fintechs**:
    - **Google**, **Amazon**, **Microsoft**, **Uber**, **Atlassian**, **Rippling**, **Dream11**
    - **Coinbase**, **Stripe**, **Databricks**, **DE Shaw**, **Rubrik**, **Glean**, **Cohesity**, **Confluent**

These companies reportedly:

- Offer **freshers 60L–1 Cr CTC** from top IITs (especially in CSE).
- Pay even higher for experienced folks — **1.2–1.4 Cr** for SDE-3+ roles (5–8 YOE).
- Mix of **base + performance bonus + equity**. For instance:
    - ~60L base
    - ~20–30L stock/equity
    - Some include joining bonus or relocation

---

### 🧠 **Entry Barriers & Reality Check**

- HFTs and top-tier roles have **extremely difficult interviews**.
- Many people (even IITians) **struggle to get calls** or pass rounds at Uber, Jane Street, etc.
- The **1 Cr CTC** jobs exist — but for a **very small fraction** of engineers.

---

### 🏡 **Post-1Cr Salary Moves**

- Some move abroad (NY, London, Singapore)
- Some invest heavily in **real estate**
- Others just... keep grinding with **no life after work**

---

### 💬 Notable Quotes from the Thread

> "You can’t have it all buddy, that’s why they pay that high."
> 

> "Start buying real estate left right and center lol :)"
> 

> "I'm reading this on 3.5 LPA. Yelp!"
> 

> "With 8 years experience in DE, nobody wants to pay 30L+."
> 

> "Not gloating. Just trying to show the state of the market."
> 

---

### 🔍 Extra Insights

- **Atlassian** follows a **global pay standard** (100K USD+ for roles, adjusted upward in costly regions).
- **Levels.fyi** was mentioned to understand roles like **SDE-3 (Uber)**, **L63 (Microsoft)**, **L5A (Google)**, etc.

---

### 💡 Takeaways if You’re Aspiring for These Roles

1. **Aim for elite roles early** – IITs/NITs and competitive programming help.
2. **Build profile** – Open source, LeetCode, system design, AI/ML experience.
3. **Target smartly** – HFTs, FAANG+, high-growth startups.
4. **Prepare hard** – These interviews are **brutal** and sometimes include **math + system design + DSA + low-level programming**.
5. **Don’t compare early** – Many 60–70L engineers came from **4–6 years of grind**, not shortcuts.