# interview & negotiation

<aside>
💯

Tips :

Talk, talk, talk throughout the interview. Speak slowly and calmly. Even if I was internally panicked and stumped, I tried to remain cool and positive. If you need a couple of minutes to think in silence, feel free to say so and they're always happy to give it. Before jumping into coding, explain the approach you're going to take and why, as well as other alternatives you considered. Talk through the program as you're coding. When you're done, do a final verbal run-through of the program. Then write and explain your tests. Always test unless otherwise told (print statements should be fine). Consider edge cases.

</aside>

<aside>
💯

Negotition Tips :
You should always negotiate. Take it as a given in your job search. I negotiated all of my offer TCs up about 10% by having competing offers. My main resource was Haseeb Q's [10 Rules for Negotiating a Job Offer](https://haseebq.com/my-ten-rules-for-negotiating-a-job-offer/). I highly recommend reading and taking notes on both parts 1 and 2. But the biggest takeaways for me were to A) keep your cards a bit closer to your chest. Let your recruiter put out the first number if possible and don't reveal what other offers you have unless it works in your favor. B) Have alternatives! Whether it be other offers, on-sites, grad school, or staying in your current job. This is what actually gives you leverage in negotiations. Competing offers is the strongest leverage, but the others will do too. And C) Be excitable and personable the entire time. The second you show disinterest in the company, you've lost one of your biggest assets as a candidate which is your excitement. It's what makes them believe you have a chance of accepting and will do good work.

</aside>